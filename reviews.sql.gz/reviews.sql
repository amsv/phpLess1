-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 04 2020 г., 15:29
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `dbmarket`
--

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `fio` varchar(255) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `comment` text NOT NULL,
  `id_good` int NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `fio`, `email`, `comment`, `id_good`, `date_create`) VALUES
(1, 'Алексей', 'teats@tedt.ru', 'Товар отличный!!!!', 0, '2020-05-04 01:26:21'),
(2, 'Егор', 'test@test.ru', 'Товар не очень хорош', 0, '2020-05-04 01:27:21'),
(3, 'Маша', 'mail@yandex.ru', 'Ничего плохого о товаре не могу сказать', 0, '2020-05-04 01:28:21'),
(4, 'Маша', 'mail@yandex.ru', 'Ничего плохого. Только положительное.', 0, '2020-05-04 01:29:21'),
(5, 'Макс', 'mail@yandex.ru', 'Только положительное.', 0, '2020-05-04 01:23:21'),
(6, 'Ульяна', 'test@test.ru', 'орпорп', 0, '2020-05-04 01:31:09'),
(7, 'Леся', 'test11@test1.ru', 'Good!!!', 0, '2020-05-04 01:32:21'),
(8, 'Таня', 'test11@test1.ru', 'Good', 0, '2020-05-04 01:33:21'),
(9, 'Миша', 'mail11@yandex.ru', 'Полезный', 0, '2020-05-04 01:34:21'),
(10, 'Слава', 'mail12@yandex.ru', 'Хороший', 0, '2020-05-04 01:35:21'),
(11, 'Дамир', 'mail1212@yandex.ru', 'Хороший гель', 1, '2020-05-04 01:36:21'),
(12, 'Дарья', 'test126@test.ru', 'Плохой товар', 0, '2020-05-04 01:37:21'),
(13, 'Женя', 'test44@test.ru', 'Хороший товар', 0, '2020-05-04 01:39:29'),
(14, 'Антонина', 'test55@test.ru', 'Сушит кожу', 2, '2020-05-04 01:41:18'),
(15, 'Ульяна', 'test@test.ru', 'Содержит алоэ', 3, '2020-05-04 01:44:42'),
(16, 'Егор', 'wqe@aweqw.ry', 'Хорош', 4, '2020-05-04 01:46:41');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
